abstract public class RedBus
{
 String cname;
 long cno;
 String src;
 String dst;
 String date;
 String time;
 double dist;
 int seat;
 int password;

 abstract public void done();


	RedBus()
	{
	}

	RedBus(String src,String dst,int seat,String date,String time)//reservation
	{
		this.src=src;
		this.dst=dst;
		this.seat=seat;
		this.date=date;
		this.time=time;

	}
RedBus(int seat,double dist,int password,String cname,long cno)//payment
	{
		this.seat=seat;
		this.dist=dist;
		this.password=password;
		this.cname=cname;
		this.cno=cno;

	}
	RedBus(String src,String dst,int seat,double dist,String date,String time,String cname,long cno)//details
	{
		this.src=src;
		this.dst=dst;
		this.seat=seat;
		this.dist=dist;
		this.date=date;
		this.time=time;
		this.cname=cname;
		this.cno=cno;
	}
	
}