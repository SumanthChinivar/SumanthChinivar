 import java.util.Scanner;
public class Payment extends RedBus
{
	Scanner r=new Scanner(System.in);
	private double price=37;
	double total ;
	
	public void done()
		{
		System.out.println("Enter the password for verification");
		int pass=r.nextInt();
				
				if (pass==password)
				{
					System.out.println("-------------------------");
					System.out.println("You can make your payment");
					System.out.println("We charge rs.37/- per km");
					
					
					System.out.println("==========================");
					
					System.out.println("we charge "  +total+ "rs for your journey");
					System.out.println("--------------------------------");
					
				
				}
				else
				System.out.println("You are not an authorized person please leave the page");
	}
	Payment()
	{
	}
	Payment(int seat,double dist,int password,String cname,long cno)
	{
		super(seat,dist,password,cname,cno);
	}
		
	{
		total=price * dist * seat;
	}

}
