import java.util.Scanner;

public  class  RedBusDrive
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println(" WELCOME TO RED BUS");
		System.out.println(" enter your name");
		String cname=s.nextLine();
		System.out.println("enter your number");
		long cno=s.nextLong();
		System.out.println("set a password for further use which consists on numbers ");
		int password=s.nextInt();
		 
			RedBus r;
			int i=1;
			while(i==1)
		{
			System.out.println("Do you want to make new reservations");
				int yes=s.nextInt();
				if(yes==0)
			{
				System.out.println("Your Reservation failed");
					break;			
			}
		else
		{	
			System.out.println(" Please enter the source  ");
			String src=s.next();
			System.out.println("Please enter the destination ");
			String dst=s.next();
			System.out.println("please enter the distance covered between source and destination ");
			double dist = s.nextDouble();
			System.out.println("please enter the date you want to travel");
			String date=s.next();
			System.out.println("please enter the number of seats you want to book");
			int seat=s.nextInt();
			System.out.println("please enter the time");
			String time=s.next();
			r=new Reservation(src,dst,seat,date,time);
			r.done();
			int choice;
			System.out.println("Do you want to make payments");
			int j=s.nextInt();
			if(j==0)
				{
				System.out.println("Your payment has not been done");
				break;
				}
			else 
				{
				RedBus r1=new Payment(seat,dist,password,cname,cno);
				r1.done();
				}
			System.out.println("Do you want to print details");
			int k=s.nextInt();
			if(k==0)
				System.out.println("Thank you");
			else
				{
				RedBus r2=new Details(src,dst,seat,dist,date,time,cname,cno);
				r2.done();
				}
			}
		}
	}
}

