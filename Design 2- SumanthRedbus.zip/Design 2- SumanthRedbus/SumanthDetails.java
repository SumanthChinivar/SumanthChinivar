 public class Details extends RedBus
{
	private double total;
     double price=37;
	Details()
	{
	}
	Details(String src,String dst,int seat,double dist,String date,String time,String cname,long cno)
	{
		super(src,dst,seat,dist,date,time,cname,cno);
	}
 public void done()
	{
	 total=price*dist*seat;
	 System.out.println("Dear "+cname+ " with phone number" +cno+ " here are the details of your Reservation");
	 System.out.println("your ride is from: "+src);
	 System.out.println("your ride is to: "+dst);
	 System.out.println("you have booked for : "+seat+"s");
	 System.out.println("your ride is on: "+date);
	 System.out.println("your ride is at: "+time);
	 System.out.println("your ride fare is: "+total);
	 System.out.println("Happy Journey ");
	}
		
	}
 
