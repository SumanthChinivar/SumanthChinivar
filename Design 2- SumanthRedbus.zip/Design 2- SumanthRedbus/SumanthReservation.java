public class Reservation extends RedBus
{
public void done()
	{		
		System.out.println("==================");
		System.out.println("your source is   "+src);
		System.out.println("your destination is   "+dst);
		System.out.println("your distance is   "+dist);
		System.out.println("your travelling Date  on  "+date);
        System.out.println("your travelling time  at  "+time);
		System.out.println("=============================");

			
	}



	

	Reservation()
	{
	}

	Reservation(String src,String dst,int seat,String date,String time)
	{
		super(src,dst,seat,date,time);
	}


}