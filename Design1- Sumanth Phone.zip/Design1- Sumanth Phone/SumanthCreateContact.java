import java.util.Scanner;
class CreateContact extends Phone
{
	long cnumber;
	String cname;
	Scanner s=new Scanner(System.in);
	CreateContact()
	{
		if(lock==1)
		{
			unlockPhone();
		}
		System.out.println("++++++++++++++=============++++++++++++++");
		System.out.println("Contacts is opened");
		System.out.println("Enter the contact name and contact number");
		cname=s.next();
		cnumber=s.nextLong();
		System.out.println(" Contact has been created successfully");
		System.out.println("++++++++++++++=============++++++++++++++");
		System.out.println("The contact name is: "+cname+"\n The contact number is:" +cnumber);
		System.out.println("+++++++++========+++++++========");
		lock=1;
	}

	public void unlockPhone()
	{
		int pw;
		System.out.println("Enter the password to unlock the phone");
		pw=s.nextInt();
		if(password==pw)
		{
			System.out.println("Phone is unlocked");
			lock=0;
		}
		else
			System.out.println("Enter the correct password");
	}
}
