import java.util.Scanner;
class Message extends Phone
{
	String msg;
	int i;
	Scanner s=new Scanner(System.in);
	Message()
	{
		if(lock==1)
		{
			unlockPhone();
		}
		System.out.println("++++++++++++++=============++++++++++++++");
		System.out.println("Messages has been opened");
		System.out.println(" Do you want to create a message");
		i=s.nextInt();
		if(i==1)
		{
		System.out.println("Enter the message to be sent");
		msg=s.next();
		System.out.println("Message has been sent");
		System.out.println("++++++++++++++=============++++++++++++++");
		lock=1;
		}
	}


	public void unlockPhone()
	{
		int pw;
		System.out.println("Enter the password to unlock the phone");
		pw=s.nextInt();
		if(password==pw)
		{
			System.out.println("Phone is unlocked");
			lock=0;
		}
		else
			System.out.println("Enter the correct password");
	}

}