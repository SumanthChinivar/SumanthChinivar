abstract class Phone
{
	private String ownername;
	int lock=1;
	int password=1234;

	Phone()
	{
	}
	Phone(String owner)
	{
		this.ownername=owner;
	}

	public void setOwner(String owner)
	{
		this.ownername=owner;
	}
	public String getOwner()
	{
		return ownername;
	}

abstract void unlockPhone();
	
}